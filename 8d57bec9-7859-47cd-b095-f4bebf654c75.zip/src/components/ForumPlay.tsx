import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Brain,
  Link as LinkIcon,
  Globe,
  CheckCircle2,
  XCircle } from
'lucide-react';
import { cn } from '../lib/utils';
export function ForumPlay() {
  const [guessState, setGuessState] = useState<'idle' | 'correct' | 'wrong'>(
    'idle'
  );
  const [revealedClues, setRevealedClues] = useState(1);
  const mastermindClues = [
  'Ia pernah dipenjara oleh pemerintah kolonial Belanda dan Orde Baru.',
  'Karya terbesarnya ditulis secara lisan sebelum akhirnya dicatat di atas kertas buram.',
  'Ia adalah kandidat terkuat peraih Nobel Sastra dari Indonesia.'];

  const mastermindOptions = [
  'Chairil Anwar',
  'Pramoedya Ananta Toer',
  'Mochtar Lubis'];

  const handleGuess = (option: string) => {
    if (option === 'Pramoedya Ananta Toer') {
      setGuessState('correct');
    } else {
      setGuessState('wrong');
    }
  };
  return (
    <section className="py-24 bg-parchment-dark/10 border-y border-ink/5">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-ink mb-4">
            Ruang Interaksi
          </h2>
          <p className="text-ink/60">
            Uji wawasan literatur Anda, temukan koneksi tak terduga, dan
            hubungkan fiksi dengan realita.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tebak Penulis (The Mastermind) */}
          <motion.div
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            className="col-span-1 lg:col-span-2 bg-parchment border border-ink/10 rounded-3xl p-8 shadow-xl shadow-ink/5 relative overflow-hidden">
            
            <div className="absolute top-0 right-0 w-64 h-64 bg-zone-mystery/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />

            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-zone-mystery/10 text-zone-mystery flex items-center justify-center">
                  <Brain size={20} />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-bold text-ink">
                    The Mastermind
                  </h3>
                  <p className="text-xs font-medium text-ink/50 uppercase tracking-wider">
                    Tebak Penulis
                  </p>
                </div>
              </div>

              <div className="mb-8">
                <p className="text-ink/80 mb-4">
                  Siapakah sosok di balik petunjuk ini?
                </p>
                <ul className="space-y-3">
                  {mastermindClues.map((clue, idx) =>
                  <li
                    key={idx}
                    className={cn(
                      'p-4 rounded-xl text-sm transition-all duration-500',
                      idx < revealedClues ?
                      'bg-ink/5 text-ink/90 border border-ink/10' :
                      'bg-ink/5 text-transparent select-none blur-sm border border-transparent'
                    )}>
                    
                      {idx < revealedClues ? clue : 'Petunjuk terkunci...'}
                    </li>
                  )}
                </ul>

                {revealedClues < mastermindClues.length &&
                guessState === 'idle' &&
                <button
                  onClick={() => setRevealedClues((prev) => prev + 1)}
                  className="mt-4 text-xs font-bold text-zone-mystery hover:text-ink transition-colors">
                  
                      + Buka Petunjuk Selanjutnya
                    </button>
                }
              </div>

              {guessState === 'idle' ?
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {mastermindOptions.map((opt, idx) =>
                <button
                  key={idx}
                  onClick={() => handleGuess(opt)}
                  className="p-3 rounded-xl border border-ink/20 text-sm font-medium text-ink hover:bg-ink hover:text-parchment transition-colors">
                  
                      {opt}
                    </button>
                )}
                </div> :

              <div
                className={cn(
                  'p-6 rounded-2xl border text-center',
                  guessState === 'correct' ?
                  'bg-zone-nonfic/10 border-zone-nonfic/20 text-zone-nonfic' :
                  'bg-zone-comic/10 border-zone-comic/20 text-zone-comic'
                )}>
                
                  {guessState === 'correct' ?
                <>
                      <CheckCircle2 size={32} className="mx-auto mb-3" />
                      <h4 className="font-bold text-lg mb-1">Tepat Sekali!</h4>
                      <p className="text-sm opacity-80">
                        Anda mendapatkan +50 Poin Forum. Pramoedya Ananta Toer
                        adalah maestro sejati.
                      </p>
                    </> :

                <>
                      <XCircle size={32} className="mx-auto mb-3" />
                      <h4 className="font-bold text-lg mb-1">Belum Tepat</h4>
                      <p className="text-sm opacity-80">
                        Coba lagi besok untuk tantangan Mastermind berikutnya.
                      </p>
                    </>
                }
                  <button
                  onClick={() => {
                    setGuessState('idle');
                    setRevealedClues(1);
                  }}
                  className="mt-4 text-xs font-bold underline opacity-70 hover:opacity-100">
                  
                    Ulangi Simulasi
                  </button>
                </div>
              }
            </div>
          </motion.div>

          <div className="col-span-1 flex flex-col gap-8">
            {/* Rekomendasi Kembaran */}
            <motion.div
              initial={{
                opacity: 0,
                y: 20
              }}
              whileInView={{
                opacity: 1,
                y: 0
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: 0.1
              }}
              className="bg-parchment border border-ink/10 rounded-3xl p-6 shadow-xl shadow-ink/5">
              
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 rounded-lg bg-zone-classic/10 text-zone-classic flex items-center justify-center">
                  <LinkIcon size={16} />
                </div>
                <h3 className="font-serif text-lg font-bold text-ink">
                  Rekomendasi Kembaran
                </h3>
              </div>

              <p className="text-xs text-ink/60 mb-4">
                Vibe yang sama, beda benua.
              </p>

              <div className="flex items-center justify-between gap-2">
                <div className="flex-1 text-center">
                  <img
                    src="https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=150&h=200"
                    alt="1984 Cover"
                    className="w-full h-24 object-cover rounded-md mb-2 grayscale opacity-80" />
                  
                  <p className="text-[10px] font-bold text-ink truncate">
                    1984
                  </p>
                  <p className="text-[9px] text-ink/50">George Orwell</p>
                </div>

                <div className="flex flex-col items-center px-2">
                  <div className="w-full h-px bg-ink/20 mb-1" />
                  <span className="text-[8px] font-bold uppercase tracking-widest text-ink/40">
                    Distopia
                  </span>
                  <div className="w-full h-px bg-ink/20 mt-1" />
                </div>

                <div className="flex-1 text-center">
                  <img
                    src="https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=150&h=200"
                    alt="Cantik Itu Luka Cover"
                    className="w-full h-24 object-cover rounded-md mb-2 grayscale opacity-80" />
                  
                  <p className="text-[10px] font-bold text-ink truncate">
                    Cantik Itu Luka
                  </p>
                  <p className="text-[9px] text-ink/50">Eka Kurniawan</p>
                </div>
              </div>
            </motion.div>

            {/* Buku vs Dunia Nyata */}
            <motion.div
              initial={{
                opacity: 0,
                y: 20
              }}
              whileInView={{
                opacity: 1,
                y: 0
              }}
              viewport={{
                once: true
              }}
              transition={{
                delay: 0.2
              }}
              className="bg-parchment border border-ink/10 rounded-3xl p-6 shadow-xl shadow-ink/5 flex-grow">
              
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded-lg bg-zone-modern/10 text-zone-modern flex items-center justify-center">
                  <Globe size={16} />
                </div>
                <h3 className="font-serif text-lg font-bold text-ink">
                  Buku vs Realita
                </h3>
              </div>

              <h4 className="text-sm font-bold text-ink mb-2">
                Dune & Krisis Iklim
              </h4>
              <p className="text-xs text-ink/70 leading-relaxed">
                Ekologi Arrakis karya Frank Herbert kini semakin relevan.
                Bagaimana fiksi spekulatif tahun 1965 memprediksi perebutan
                sumber daya dan krisis air di abad ke-21?
              </p>
              <button className="mt-4 text-xs font-bold text-zone-modern hover:text-ink transition-colors">
                Baca Diskusi →
              </button>
            </motion.div>
          </div>
        </div>
      </div>
    </section>);

}