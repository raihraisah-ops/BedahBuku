import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Sparkles,
  Star,
  Heart,
  MessageCircle,
  ChevronRight,
  Search } from
'lucide-react';
import { AI_REVIEWS } from '../data/mock';
import { cn } from '../lib/utils';
export function LibroVibePanel() {
  const [activeReviewId, setActiveReviewId] = useState(AI_REVIEWS[0].id);
  const activeReview =
  AI_REVIEWS.find((r) => r.id === activeReviewId) || AI_REVIEWS[0];
  return (
    <section
      id="reviews"
      className="py-24 bg-ink text-parchment overflow-hidden relative">
      
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-zone-classic/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-zone-scifi/10 rounded-full blur-3xl translate-y-1/3 -translate-x-1/3 pointer-events-none" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-parchment/10 text-zone-classic mb-6">
            <Sparkles size={24} />
          </div>
          <h2 className="font-serif text-3xl md:text-5xl font-bold mb-4">
            Tanya Bedah Buku
          </h2>
          <p className="text-parchment/60 text-lg">
            Kurasi AI yang cerdas, puitis, dan objektif. Pilih buku di bawah ini
            untuk melihat contoh bagaimana Bedah Buku membedah sebuah dunia.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 max-w-6xl mx-auto">
          {/* Sidebar / Book Selector */}
          <div className="w-full lg:w-1/3 flex flex-col gap-3">
            <h3 className="text-xs font-bold uppercase tracking-widest text-parchment/40 mb-2 px-2">
              Sample Archives
            </h3>
            {AI_REVIEWS.map((review) =>
            <button
              key={review.id}
              onClick={() => setActiveReviewId(review.id)}
              className={cn(
                'flex items-center gap-4 p-3 rounded-xl text-left transition-all duration-300 border',
                activeReviewId === review.id ?
                'bg-parchment/10 border-parchment/20 shadow-lg' :
                'bg-transparent border-transparent hover:bg-parchment/5'
              )}>
              
                <img
                src={review.cover}
                alt={review.title}
                className="w-12 h-16 object-cover rounded-md shadow-sm" />
              
                <div className="flex-grow min-w-0">
                  <h4 className="font-serif font-bold text-parchment truncate">
                    {review.title}
                  </h4>
                  <p className="text-xs text-parchment/60 truncate">
                    {review.author}
                  </p>
                </div>
                <ChevronRight
                size={16}
                className={cn(
                  'transition-transform duration-300',
                  activeReviewId === review.id ?
                  'text-zone-classic translate-x-0 opacity-100' :
                  '-translate-x-2 opacity-0'
                )} />
              
              </button>
            )}
          </div>

          {/* Review Panel */}
          <div className="w-full lg:w-2/3">
            <div className="bg-parchment rounded-3xl p-8 md:p-10 text-ink shadow-2xl relative overflow-hidden">
              {/* Dynamic Background Image */}
              <AnimatePresence mode="wait">
                <motion.div
                  key={`bg-${activeReview.id}`}
                  initial={{
                    opacity: 0
                  }}
                  animate={{
                    opacity: 0.1
                  }}
                  exit={{
                    opacity: 0
                  }}
                  transition={{
                    duration: 0.6
                  }}
                  className="absolute inset-0 z-0">
                  
                  <img
                    src={activeReview.panelBg}
                    alt=""
                    className="w-full h-full object-cover" />
                  
                </motion.div>
              </AnimatePresence>

              {/* Top Accent Line */}
              <div
                className={cn(
                  'absolute top-0 left-0 w-full h-2 z-20',
                  activeReview.zoneBg.replace('/10', '')
                )} />
              

              <AnimatePresence mode="wait">
                <motion.div
                  key={activeReview.id}
                  initial={{
                    opacity: 0,
                    y: 10
                  }}
                  animate={{
                    opacity: 1,
                    y: 0
                  }}
                  exit={{
                    opacity: 0,
                    y: -10
                  }}
                  transition={{
                    duration: 0.4
                  }}
                  className="relative z-10">
                  
                  {/* Header: Badge & Title */}
                  <div className="flex flex-wrap items-start justify-between gap-4 mb-8">
                    <div>
                      <span
                        className={cn(
                          'inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-4',
                          activeReview.zoneBg,
                          activeReview.zoneColor
                        )}>
                        
                        {activeReview.zone}
                      </span>
                      <h3 className="font-serif text-3xl md:text-4xl font-bold mb-2">
                        {activeReview.title}
                      </h3>

                      {/* Sang Maestro Block */}
                      <div className="mt-6 bg-ink/5 p-4 rounded-2xl border border-ink/10 max-w-md">
                        <h4 className="text-[10px] font-bold uppercase tracking-widest text-ink/40 mb-3 flex items-center gap-2">
                          <span className="w-4 h-px bg-ink/20" />
                          Sang Maestro
                        </h4>
                        <div className="flex items-start gap-4">
                          <img
                            src={activeReview.authorPhoto}
                            alt={`Placeholder for ${activeReview.author}`}
                            className="w-12 h-12 rounded-full object-cover grayscale opacity-80 border border-ink/10" />
                          
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-ink leading-tight mb-1">
                              {activeReview.author}
                            </span>
                            <span className="text-[10px] text-ink/60 italic mb-2">
                              {activeReview.authorNote}
                            </span>
                            {activeReview.authorBio &&
                            <p className="text-xs text-ink/70 leading-relaxed">
                                {activeReview.authorBio}
                              </p>
                            }
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Ratings Block */}
                    <div className="flex items-center gap-6 bg-parchment-dark/50 px-5 py-3 rounded-2xl border border-ink/5">
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] uppercase tracking-wider text-ink/50 font-bold mb-1">
                          Obj. Craft
                        </span>
                        <div className="flex items-center gap-1.5 font-serif text-xl font-bold">
                          {activeReview.ratingObj.toFixed(1)}
                          <Star
                            size={16}
                            className="fill-zone-classic text-zone-classic" />
                          
                        </div>
                      </div>
                      <div className="w-px h-10 bg-ink/10" />
                      <div className="flex flex-col items-center">
                        <span className="text-[10px] uppercase tracking-wider text-ink/50 font-bold mb-1">
                          Subj. Vibe
                        </span>
                        <div className="flex items-center gap-1.5 font-serif text-xl font-bold">
                          {activeReview.ratingSub.toFixed(1)}
                          <Heart
                            size={16}
                            className="fill-zone-modern text-zone-modern" />
                          
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Verdict */}
                  <div className="mb-8">
                    <p className="font-serif text-xl md:text-2xl text-ink leading-relaxed italic border-l-4 border-ink/20 pl-6 py-2">
                      {activeReview.verdict}
                    </p>
                  </div>

                  {/* Potongan Jiwa (Quotes Wall) */}
                  {activeReview.quotes && activeReview.quotes.length > 0 &&
                  <div className="mb-10 bg-parchment-dark/30 p-6 rounded-2xl border border-ink/5">
                      <h4 className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-ink/40 mb-4">
                        <span className="text-lg">🖋️</span>
                        Potongan Jiwa
                      </h4>
                      <div className="space-y-4">
                        {activeReview.quotes.map((quote, idx) =>
                      <blockquote
                        key={idx}
                        className="border-l-2 border-zone-classic/50 pl-4">
                        
                            <p className="font-serif text-lg text-ink/90 italic mb-2">
                              "{quote}"
                            </p>
                            {idx === activeReview.quotes.length - 1 &&
                        <footer className="text-xs font-medium text-ink/50">
                                —{' '}
                                <cite className="not-italic">
                                  {activeReview.title}
                                </cite>
                                , {activeReview.author}
                              </footer>
                        }
                          </blockquote>
                      )}
                      </div>
                    </div>
                  }

                  {/* Dissection */}
                  <div className="mb-10">
                    <h4 className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-ink/40 mb-4">
                      <Search size={16} />
                      Bedah Dunia
                    </h4>
                    <p className="text-ink/80 leading-relaxed text-lg whitespace-pre-line">
                      {activeReview.dissection.includes('⚠️ SPOILER ALERT') ?
                      <>
                          <span className="inline-block px-2 py-0.5 bg-zone-comic/10 text-zone-comic text-xs font-bold rounded mb-2 border border-zone-comic/20">
                            ⚠️ SPOILER ALERT
                          </span>
                          <br />
                          {activeReview.dissection.replace(
                          '⚠️ SPOILER ALERT: ',
                          ''
                        )}
                        </> :

                      activeReview.dissection
                      }
                    </p>
                  </div>

                  {/* Sparks */}
                  <div className="mb-8">
                    <h4 className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-ink/40 mb-4">
                      <MessageCircle size={16} />
                      Percikan Diskusi
                    </h4>
                    <div className="flex flex-col gap-3">
                      {activeReview.sparks.map((spark, idx) =>
                      <button
                        key={idx}
                        className="flex items-start gap-3 text-left p-4 rounded-xl bg-ink/5 hover:bg-ink/10 border border-transparent hover:border-ink/10 transition-colors group">
                        
                          <span className="flex-shrink-0 w-6 h-6 rounded-full bg-parchment flex items-center justify-center text-xs font-bold text-ink/50 group-hover:text-ink transition-colors shadow-sm">
                            {idx + 1}
                          </span>
                          <span className="text-ink/80 font-medium pt-0.5 leading-snug group-hover:text-ink transition-colors">
                            {spark}
                          </span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Persistent Reminder */}
                  <div className="pt-6 border-t border-ink/10 text-center">
                    <p className="text-xs font-medium text-ink/40 uppercase tracking-widest">
                      Di forum Bedah Buku, tidak ada interpretasi yang salah.
                    </p>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </section>);

}