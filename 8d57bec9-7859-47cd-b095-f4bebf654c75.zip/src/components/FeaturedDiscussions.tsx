import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Heart, Star, ArrowRight } from 'lucide-react';
import { FEATURED_DISCUSSIONS } from '../data/mock';
import { cn } from '../lib/utils';
export function FeaturedDiscussions() {
  return (
    <section id="discussions" className="py-24">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-ink mb-3">
              Trending Discussions
            </h2>
            <p className="text-ink/60 max-w-xl">
              Percakapan paling hangat minggu ini. Bergabunglah untuk membedah
              karakter, plot, dan filosofi di balik karya-karya ini.
            </p>
          </div>
          <button className="flex items-center gap-2 text-sm font-medium text-ink hover:text-zone-classic transition-colors group">
            View all discussions
            <ArrowRight
              size={16}
              className="group-hover:translate-x-1 transition-transform" />
            
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURED_DISCUSSIONS.map((book, index) =>
          <motion.div
            key={book.id}
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              duration: 0.5,
              delay: index * 0.1
            }}
            className="group flex flex-col bg-parchment border border-ink/10 rounded-2xl overflow-hidden hover:shadow-xl hover:shadow-ink/5 hover:border-ink/20 transition-all duration-300">
            
              {/* Cover Image Area */}
              <div className="relative h-64 overflow-hidden bg-ink/5">
                <img
                src={book.cover}
                alt={book.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out" />
              
                <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent opacity-80" />

                {/* Zone Badge */}
                <div className="absolute top-4 left-4">
                  <span
                  className={cn(
                    'px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-md border border-white/20 text-white',
                    book.zoneBg.replace('/10', '/40')
                  )}>
                  
                    {book.zone}
                  </span>
                </div>

                {/* Title & Author overlay */}
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <h3 className="font-serif text-xl font-bold leading-tight mb-1">
                    {book.title}
                  </h3>
                  <p className="text-sm text-white/80">{book.author}</p>
                </div>
              </div>

              {/* Content Area */}
              <div className="p-5 flex flex-col flex-grow">
                {/* Ratings Split */}
                <div className="flex items-center gap-4 mb-4 pb-4 border-b border-ink/10">
                  <div className="flex flex-col">
                    <span className="text-[10px] uppercase tracking-wider text-ink/50 font-semibold mb-1">
                      Obj. Craft
                    </span>
                    <div className="flex items-center gap-1 text-ink font-medium">
                      <Star
                      size={14}
                      className="fill-zone-classic text-zone-classic" />
                    
                      {book.ratingObj.toFixed(1)}
                    </div>
                  </div>
                  <div className="w-px h-8 bg-ink/10" />
                  <div className="flex flex-col">
                    <span className="text-[10px] uppercase tracking-wider text-ink/50 font-semibold mb-1">
                      Subj. Vibe
                    </span>
                    <div className="flex items-center gap-1 text-ink font-medium">
                      <Heart
                      size={14}
                      className="fill-zone-modern text-zone-modern" />
                    
                      {book.ratingSub.toFixed(1)}
                    </div>
                  </div>
                </div>

                {/* Teaser */}
                <p className="text-sm text-ink/80 leading-relaxed italic mb-6 flex-grow">
                  {book.teaser}
                </p>

                {/* Footer Stats */}
                <div className="flex items-center justify-between text-xs font-medium text-ink/50 mt-auto pt-2">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1.5 hover:text-ink transition-colors cursor-pointer">
                      <MessageSquare size={14} />
                      {book.replies} Replies
                    </span>
                    <span className="flex items-center gap-1.5 hover:text-zone-modern transition-colors cursor-pointer">
                      <Heart size={14} />
                      {book.likes}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

}