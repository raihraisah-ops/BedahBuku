import React from 'react';
import { BookOpen, Sparkles } from 'lucide-react';
export function Footer() {
  return (
    <footer className="bg-parchment-dark/50 border-t border-ink/10 pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start gap-12 mb-16">
          <div className="max-w-sm">
            <div className="flex items-center gap-2 text-ink mb-4">
              <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-ink text-parchment">
                <BookOpen size={16} />
                <Sparkles
                  size={10}
                  className="absolute -top-1 -right-1 text-zone-classic" />
                
              </div>
              <span className="font-serif text-2xl font-bold tracking-tight">
                Bedah Buku
              </span>
            </div>
            <p className="text-ink/60 leading-relaxed">
              Suaka global bagi para pembaca. Kami memperlakukan setiap buku
              bukan sekadar tumpukan kertas, melainkan sebagai karya seni yang
              harus dibedah hingga ke akar-akarnya.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-12">
            <div>
              <h4 className="font-bold text-ink mb-4">Zones</h4>
              <ul className="space-y-2 text-sm text-ink/60">
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    Classic Literature
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    Modern Fiction
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    Sci-Fi & Fantasy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    Mystery & Thriller
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    Mind Expanding
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-ink mb-4">Platform</h4>
              <ul className="space-y-2 text-sm text-ink/60">
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    Discussions
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    AI Reviews
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    Community Guidelines
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-ink transition-colors">
                    About LibroVibe
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-ink/10 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-ink/40">
          <p>© {new Date().getFullYear()} Bedah Buku. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-ink transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-ink transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>);

}