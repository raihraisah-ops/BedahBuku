import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Sparkles } from 'lucide-react';
export function Hero() {
  return (
    <section className="relative pt-24 pb-32 overflow-hidden">
      {/* Mandatory Hero Background: Classic Library */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=2000"
          alt="Classic library with warm lighting"
          className="w-full h-full object-cover" />
        
        {/* Warm parchment/ink gradient overlay to ensure text legibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-parchment/95 via-parchment/90 to-parchment/95 backdrop-blur-[2px]" />
      </div>

      {/* Subtle background decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-zone-classic/10 rounded-full blur-3xl z-0 pointer-events-none" />

      <div className="container mx-auto px-4 text-center max-w-4xl relative">
        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.7,
            ease: 'easeOut'
          }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-ink/10 bg-parchment-dark/30 text-xs font-medium text-ink/70 mb-8">
          
          <Sparkles size={12} className="text-zone-classic" />
          <span>AI-Curated Literary Forum</span>
        </motion.div>

        <motion.h1
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.7,
            delay: 0.1,
            ease: 'easeOut'
          }}
          className="font-serif text-5xl md:text-7xl font-bold text-ink leading-[1.1] mb-6 tracking-tight">
          
          Setiap buku adalah dunia <br className="hidden md:block" />
          <span className="italic font-light text-ink-light">
            yang layak dibedah.
          </span>
        </motion.h1>

        <motion.p
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.7,
            delay: 0.2,
            ease: 'easeOut'
          }}
          className="text-lg md:text-xl text-ink/70 mb-10 max-w-2xl mx-auto leading-relaxed">
          
          Selamat datang di Bedah Buku. Suaka global bagi para pembaca untuk
          mengeksplorasi literatur, memicu diskusi mendalam, dan menemukan
          wawasan analitis yang dikurasi oleh AI. Kami membedah setiap karya
          seni hingga ke akar-akarnya.
        </motion.p>

        <motion.div
          initial={{
            opacity: 0,
            y: 20
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            duration: 0.7,
            delay: 0.3,
            ease: 'easeOut'
          }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4">
          
          <button className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-ink text-parchment font-medium hover:bg-ink-light transition-colors shadow-lg shadow-ink/10">
            <MessageSquare size={18} />
            <span>Start a discussion</span>
          </button>
          <button className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-full bg-transparent border border-ink/20 text-ink font-medium hover:bg-ink/5 transition-colors">
            <Sparkles size={18} />
            <span>Get a review</span>
          </button>
        </motion.div>

        {/* Floating quote detail */}
        <motion.div
          initial={{
            opacity: 0,
            x: 20
          }}
          animate={{
            opacity: 1,
            x: 0
          }}
          transition={{
            duration: 1,
            delay: 0.8,
            ease: 'easeOut'
          }}
          className="absolute right-0 top-1/4 hidden lg:block max-w-[200px] text-left">
          
          <p className="font-serif text-sm italic text-ink/50 leading-relaxed border-l border-ink/20 pl-4">
            "A reader lives a thousand lives before he dies."
          </p>
        </motion.div>
      </div>
    </section>);

}