import React from 'react';
import { motion } from 'framer-motion';
import {
  Feather,
  Coffee,
  Rocket,
  Search,
  Compass,
  ArrowRight,
  Zap } from
'lucide-react';
import { CATEGORY_ZONES } from '../data/mock';
import { cn } from '../lib/utils';
const iconMap: Record<string, React.ElementType> = {
  Feather,
  Coffee,
  Rocket,
  Search,
  Compass,
  Zap
};
export function CategoryZones() {
  return (
    <section
      id="zones"
      className="py-20 bg-parchment-dark/20 border-y border-ink/5">
      
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-4">
          <div>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-ink mb-3">
              Category Zones
            </h2>
            <p className="text-ink/60 max-w-xl">
              Pilih zona literatur Anda. Setiap kategori adalah gerbang menuju
              diskusi yang mendalam dan perspektif baru.
            </p>
          </div>
          <button className="flex items-center gap-2 text-sm font-medium text-ink hover:text-zone-classic transition-colors group">
            Explore all zones
            <ArrowRight
              size={16}
              className="group-hover:translate-x-1 transition-transform" />
            
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORY_ZONES.map((zone, index) => {
            const Icon = iconMap[zone.icon];
            return (
              <motion.div
                key={zone.id}
                initial={{
                  opacity: 0,
                  y: 20
                }}
                whileInView={{
                  opacity: 1,
                  y: 0
                }}
                viewport={{
                  once: true
                }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.1
                }}
                className="group relative flex flex-col p-6 rounded-2xl bg-parchment border border-ink/10 hover:border-ink/20 hover:shadow-xl hover:shadow-ink/5 transition-all cursor-pointer overflow-hidden">
                
                {/* Background Image */}
                {zone.bgImage &&
                <div className="absolute inset-0 z-0">
                    <img
                    src={zone.bgImage}
                    alt=""
                    className="w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-700" />
                  
                    <div className="absolute inset-0 bg-parchment/80 group-hover:bg-parchment/70 transition-colors duration-500" />
                  </div>
                }

                {/* Hover gradient background */}
                <div
                  className={cn(
                    'absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-500 z-0',
                    zone.color
                  )} />
                

                <div
                  className={cn(
                    'relative z-10 w-12 h-12 rounded-xl flex items-center justify-center mb-6 bg-parchment-dark/50 border border-ink/5',
                    zone.textColor
                  )}>
                  
                  <Icon size={24} strokeWidth={1.5} />
                </div>

                <div className="relative z-10 mb-4">
                  <h3 className="font-serif text-xl font-bold text-ink mb-1">
                    {zone.title}
                  </h3>
                  <p
                    className={cn(
                      'text-xs font-medium uppercase tracking-wider',
                      zone.textColor
                    )}>
                    
                    {zone.subtitle}
                  </p>
                </div>

                <p className="relative z-10 text-sm text-ink/70 mb-6 flex-grow leading-relaxed">
                  {zone.desc}
                </p>

                <div className="relative z-10 pt-4 border-t border-ink/10 flex items-center justify-between text-xs text-ink/50 mt-auto">
                  <span className="truncate pr-2">{zone.authors}</span>
                  <span className="flex items-center gap-1 font-medium bg-ink/5 px-2 py-1 rounded-md whitespace-nowrap">
                    {zone.discussions} <MessageCircleIcon className="w-3 h-3" />
                  </span>
                </div>
              </motion.div>);

          })}
        </div>
      </div>
    </section>);

}
function MessageCircleIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round">
      
      <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />
    </svg>);

}