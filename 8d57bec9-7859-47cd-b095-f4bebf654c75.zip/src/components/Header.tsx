import React from 'react';
import { BookOpen, Sparkles, Search, Menu } from 'lucide-react';
import { cn } from '../lib/utils';
export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-ink/10 bg-parchment/80 backdrop-blur-md">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 text-ink">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-full bg-ink text-parchment">
            <BookOpen size={16} />
            <Sparkles
              size={10}
              className="absolute -top-1 -right-1 text-zone-classic" />
            
          </div>
          <span className="font-serif text-xl font-bold tracking-tight">
            Bedah Buku
          </span>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-ink/70">
          <a href="#zones" className="hover:text-ink transition-colors">
            Zones
          </a>
          <a href="#discussions" className="hover:text-ink transition-colors">
            Discussions
          </a>
          <a href="#reviews" className="hover:text-ink transition-colors">
            Reviews
          </a>
          <a href="#community" className="hover:text-ink transition-colors">
            Community
          </a>
        </nav>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-4">
          <div className="relative group">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-ink/40 group-focus-within:text-ink/70 transition-colors" />
            
            <input
              type="text"
              placeholder="Search a world to dissect..."
              className="w-64 pl-9 pr-4 py-2 rounded-full bg-ink/5 border border-ink/10 text-sm focus:outline-none focus:ring-1 focus:ring-ink/20 focus:bg-parchment transition-all placeholder:text-ink/40" />
            
          </div>
          <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-ink text-parchment text-sm font-medium hover:bg-ink-light transition-colors">
            <Sparkles size={14} />
            <span>Tanya Bedah Buku</span>
          </button>
        </div>

        {/* Mobile Menu Toggle */}
        <button className="md:hidden p-2 text-ink">
          <Menu size={24} />
        </button>
      </div>
    </header>);

}