import React from 'react';
import { Header } from '../components/Header';
import { Hero } from '../components/Hero';
import { CategoryZones } from '../components/CategoryZones';
import { FeaturedDiscussions } from '../components/FeaturedDiscussions';
import { LibroVibePanel } from '../components/LibroVibePanel';
import { ForumPlay } from '../components/ForumPlay';
import { Footer } from '../components/Footer';
export function Home() {
  return (
    <div className="min-h-screen bg-parchment text-ink font-sans selection:bg-zone-classic/30 selection:text-ink">
      <Header />
      <main>
        <Hero />
        <CategoryZones />
        <FeaturedDiscussions />
        <LibroVibePanel />
        <ForumPlay />
      </main>
      <Footer />
    </div>);

}