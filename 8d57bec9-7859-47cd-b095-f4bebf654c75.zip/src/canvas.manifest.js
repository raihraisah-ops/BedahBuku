export const manifest = {
  screens: {
    scr_jvw5d1: { name: "Home", route: "/" }
  }
};