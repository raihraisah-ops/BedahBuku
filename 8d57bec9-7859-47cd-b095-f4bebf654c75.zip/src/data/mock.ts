export const CATEGORY_ZONES = [
{
  id: 'classic',
  title: 'Classic Literature',
  subtitle: 'Sastra Klasik',
  desc: 'Karya legendaris abad pencerahan hingga awal abad ke-20.',
  authors: 'Austen, Dostoyevsky, Pramoedya',
  color: 'bg-zone-classic',
  textColor: 'text-zone-classic',
  icon: 'Feather',
  discussions: 1240,
  bgImage:
  'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=800'
},
{
  id: 'modern',
  title: 'Modern & Contemporary',
  subtitle: 'Fiksi Modern',
  desc: 'Eksplorasi narasi pop dan fiksi kontemporer dekade terakhir.',
  authors: 'Rooney, Murakami, Eka Kurniawan',
  color: 'bg-zone-modern',
  textColor: 'text-zone-modern',
  icon: 'Coffee',
  discussions: 3892,
  bgImage:
  'https://images.unsplash.com/photo-1491841550275-ad7854e35ca6?auto=format&fit=crop&q=80&w=800'
},
{
  id: 'scifi',
  title: 'Sci-Fi & Fantasy',
  subtitle: 'Dunia Spekulatif',
  desc: 'Distopia, sihir, dan penjelajahan luar angkasa yang melampaui batas.',
  authors: 'Herbert, Tolkien, Le Guin',
  color: 'bg-zone-scifi',
  textColor: 'text-zone-scifi',
  icon: 'Rocket',
  discussions: 5120,
  bgImage:
  'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&q=80&w=800'
},
{
  id: 'mystery',
  title: 'Mystery & Thriller',
  subtitle: 'Teka-teki & Kriminal',
  desc: 'Ketegangan, plot twist, dan misteri yang menuntut pemecahan.',
  authors: 'Christie, Tartt, Flynn',
  color: 'bg-zone-mystery',
  textColor: 'text-zone-mystery',
  icon: 'Search',
  discussions: 2750,
  bgImage:
  'https://images.unsplash.com/photo-1509824227185-9c5a01ceba0d?auto=format&fit=crop&q=80&w=800'
},
{
  id: 'nonfic',
  title: 'Mind Expanding',
  subtitle: 'Non-Fiksi',
  desc: 'Biografi, sejarah, filsafat, sains populer, dan pengembangan diri.',
  authors: 'Harari, Kahneman, Aurelius',
  color: 'bg-zone-nonfic',
  textColor: 'text-zone-nonfic',
  icon: 'Compass',
  discussions: 1984,
  bgImage:
  'https://images.unsplash.com/photo-1455390582262-044cdead2708?auto=format&fit=crop&q=80&w=800'
},
{
  id: 'comic',
  title: 'Komik & Manga',
  subtitle: 'Panel & Pop-Art',
  desc: 'Eksplorasi visual, cover ikonik, dan konsep art karakter yang memukau.',
  authors: 'Junji Ito, Naoki Urasawa, komik lokal',
  color: 'bg-zone-comic',
  textColor: 'text-zone-comic',
  icon: 'Zap',
  discussions: 4210,
  bgImage:
  'https://images.unsplash.com/photo-1612036782180-6f0b6cd846fe?auto=format&fit=crop&q=80&w=800'
}];


export const FEATURED_DISCUSSIONS = [
{
  id: 1,
  title: 'Bumi Manusia',
  author: 'Pramoedya Ananta Toer',
  cover:
  'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=400&h=600',
  zone: 'Classic Literature',
  zoneColor: 'text-zone-classic',
  zoneBg: 'bg-zone-classic/10',
  ratingObj: 9.8,
  ratingSub: 9.5,
  teaser:
  '"Apakah Minke terlalu naif di awal, atau itu representasi dari kebangkitan kesadaran pribumi?"',
  replies: 142,
  likes: 320
},
{
  id: 2,
  title: 'The Secret History',
  author: 'Donna Tartt',
  cover:
  'https://images.unsplash.com/photo-1600180758890-6b94519a8ba6?auto=format&fit=crop&q=80&w=400&h=600',
  zone: 'Mystery & Thriller',
  zoneColor: 'text-zone-mystery',
  zoneBg: 'bg-zone-mystery/10',
  ratingObj: 9.0,
  ratingSub: 8.5,
  teaser:
  'Membahas dinamika toksik grup Julian. Siapa yang sebenarnya paling bertanggung jawab atas tragedi tersebut?',
  replies: 89,
  likes: 215
},
{
  id: 3,
  title: 'Dune',
  author: 'Frank Herbert',
  cover:
  'https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&q=80&w=400&h=600',
  zone: 'Sci-Fi & Fantasy',
  zoneColor: 'text-zone-scifi',
  zoneBg: 'bg-zone-scifi/10',
  ratingObj: 9.5,
  ratingSub: 9.0,
  teaser:
  'Ekologi Arrakis: Bagaimana Herbert memprediksi krisis lingkungan modern melalui fiksi spekulatif.',
  replies: 256,
  likes: 512
},
{
  id: 4,
  title: 'Sapiens',
  author: 'Yuval Noah Harari',
  cover:
  'https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&q=80&w=400&h=600',
  zone: 'Mind Expanding',
  zoneColor: 'text-zone-nonfic',
  zoneBg: 'bg-zone-nonfic/10',
  ratingObj: 8.5,
  ratingSub: 9.2,
  teaser:
  'Mitos sebagai alat pemersatu: Apakah konsep ini masih relevan di era digital yang terfragmentasi?',
  replies: 310,
  likes: 840
}];


export const AI_REVIEWS = [
{
  id: 'bumi-manusia',
  title: 'Bumi Manusia',
  author: 'Pramoedya Ananta Toer',
  authorPhoto:
  'https://images.unsplash.com/photo-1544168190-79c15427015f?auto=format&fit=crop&q=80&w=150&h=150',
  authorNote: 'Tatapan serius, klasik, hitam-putih',
  authorBio:
  'Pramoedya menghabiskan sebagian besar hidupnya dalam pengasingan, namun penanya tak pernah bisa dibungkam. Ia memandang sastra sebagai alat perlawanan mutlak terhadap ketidakadilan dan kolonialisme.',
  cover:
  'https://images.unsplash.com/photo-1589829085413-56de8ae18c73?auto=format&fit=crop&q=80&w=400&h=600',
  zone: 'Classic Literature',
  zoneColor: 'text-zone-classic',
  zoneBg: 'bg-zone-classic/10',
  panelBg:
  'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=1200',
  ratingObj: 9.8,
  ratingSub: 9.5,
  verdict:
  '"Sebuah monumen perlawanan yang ditulis dengan darah dan air mata; epik sejarah yang menolak untuk dibungkam."',
  quotes: [
  'Seorang terpelajar harus sudah berbuat adil sejak dalam pikiran apalagi dalam perbuatan.',
  'Orang boleh pandai setinggi langit, tapi selama ia tidak menulis, ia akan hilang di dalam masyarakat dan dari sejarah.'],

  dissection:
  'Pramoedya tidak sekadar menulis cerita; ia membangun kembali sebuah era. Melalui kacamata Minke, kita diajak melihat benturan keras antara feodalisme Jawa, kolonialisme Belanda, dan fajar modernitas. Karakter Nyai Ontosoroh adalah mahakarya feminisme awal yang melampaui zamannya. Secara objektif, strukturnya brilian. Secara subjektif? Buku ini akan menghancurkan sekaligus membangun kembali cara Anda melihat sejarah Indonesia.',
  sparks: [
  'Evolusi psikologis Minke dari pengagum Eropa menjadi kritikus kolonial.',
  'Nyai Ontosoroh: Korban sistem atau manipulator ulung?',
  'Relevansi konflik kelas dalam novel ini dengan masyarakat modern.']

},
{
  id: 'dune',
  title: 'Dune',
  author: 'Frank Herbert',
  authorPhoto:
  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=150&h=150',
  authorNote: 'Pandangan visioner, tajam, menembus ruang',
  authorBio:
  'Herbert adalah seorang jurnalis dan ahli ekologi amatir yang melihat fiksi ilmiah bukan sekadar pelarian, melainkan cermin untuk membedah politik, agama, dan lingkungan hidup manusia.',
  cover:
  'https://images.unsplash.com/photo-1541963463532-d68292c34b19?auto=format&fit=crop&q=80&w=400&h=600',
  zone: 'Sci-Fi & Fantasy',
  zoneColor: 'text-zone-scifi',
  zoneBg: 'bg-zone-scifi/10',
  panelBg:
  'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&q=80&w=1200',
  ratingObj: 9.5,
  ratingSub: 8.8,
  verdict:
  '"Pasir yang berbisik tentang takdir, agama, dan kekuasaan. Sebuah ekologi politik yang menyamar sebagai fiksi ilmiah."',
  quotes: [
  'I must not fear. Fear is the mind-killer. Fear is the little-death that brings total obliteration.',
  'He who controls the spice controls the universe.'],

  dissection:
  '⚠️ SPOILER ALERT: Analisis ini menyentuh nasib House Atreides.\n\nHerbert menciptakan Arrakis bukan sekadar sebagai latar, melainkan sebagai karakter utama yang bernapas. Kompleksitas politik antara faksi-faksi (Atreides, Harkonnen, Bene Gesserit) dirajut dengan sangat rapi. Pembangunan dunianya (world-building) tak tertandingi, meski pacing di pertengahan buku mungkin terasa lambat bagi sebagian pembaca. Ini bukan sekadar cerita tentang pahlawan terpilih, melainkan peringatan bahaya tentang mesianisme.',
  sparks: [
  'Apakah Paul Atreides seorang pahlawan atau tiran yang tertunda?',
  'Analisis ekologi Arrakis sebagai metafora eksploitasi minyak Timur Tengah.',
  'Peran Bene Gesserit: Manipulasi genetik vs Kehendak bebas.']

},
{
  id: 'secret-history',
  title: 'The Secret History',
  author: 'Donna Tartt',
  authorPhoto:
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150&h=150',
  authorNote: 'Elegan, misterius, dengan aura intelektual',
  authorBio:
  'Tartt dikenal dengan gaya hidupnya yang tertutup dan dedikasinya yang luar biasa pada prosa. Ia menulis satu novel setiap dekade, memastikan setiap kalimat dipahat dengan presisi klasik.',
  cover:
  'https://images.unsplash.com/photo-1600180758890-6b94519a8ba6?auto=format&fit=crop&q=80&w=400&h=600',
  zone: 'Mystery & Thriller',
  zoneColor: 'text-zone-mystery',
  zoneBg: 'bg-zone-mystery/10',
  panelBg:
  'https://images.unsplash.com/photo-1509824227185-9c5a01ceba0d?auto=format&fit=crop&q=80&w=1200',
  ratingObj: 9.0,
  ratingSub: 9.2,
  verdict:
  '"Kecantikan yang mematikan. Sebuah studi elegan tentang bagaimana estetika dapat menutupi kebusukan moral."',
  quotes: [
  'Beauty is rarely soft or consolatory. Quite the contrary. Genuine beauty is always quite alarming.',
  'Forgive me, for all the things I did but mostly for the ones that I did not.'],

  dissection:
  'Tartt membalikkan genre misteri: kita tahu siapa yang dibunuh dan siapa pembunuhnya sejak halaman pertama. Pertanyaannya bukan "siapa", melainkan "mengapa". Prosa Tartt sangat memabukkan, menarik kita ke dalam elitisme beracun kelas Yunani Kuno di Hampden College. Karakter-karakternya pretensius, egois, namun entah bagaimana, kita tidak bisa berhenti membaca kehancuran mereka.',
  sparks: [
  'Dampak isolasi akademis terhadap moralitas kelompok.',
  'Apakah Richard Papen narator yang bisa dipercaya?',
  'Kecantikan vs Kebaikan: Ilusi estetika dalam pembunuhan Bunny.']

}];