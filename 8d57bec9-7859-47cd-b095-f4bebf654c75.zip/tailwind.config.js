
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Inter"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        serif: ['"Playfair Display"', 'ui-serif', 'Georgia', 'serif'],
      },
      colors: {
        parchment: {
          DEFAULT: '#F9F7F1',
          dark: '#EBE6D9',
        },
        ink: {
          DEFAULT: '#2C2A25',
          light: '#4A473E',
          lighter: '#736F63',
        },
        zone: {
          classic: '#B8860B', // Golden Sepia
          modern: '#E2725B',  // Terracotta
          scifi: '#4B0082',   // Deep Indigo
          mystery: '#8B0000', // Crimson
          nonfic: '#2E8B57',  // Forest Green
          comic: '#D7263D',   // Punchy Pop Red
        }
      },
    },
  },
  plugins: [],
}
